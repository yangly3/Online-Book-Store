<?php include('server.php')?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Log In</title>
<link href="demo.css" rel="stylesheet" type="text/css">
	</head>
	
	<body>
	   <div class="header">
        <p><a href="#">ICS199 G15 Online Book Store</a></p>
        </div>
	
	    <div class="top_banner">
			
            <div class="top_logo"><img src="Images/1.jpeg" alt="LOGO" />
			</div>
         
        <nav class="dropdownmenu">
          <ul>
               <li><a href="Product_View.php">&nbsp;&nbsp;&nbsp;Home&nbsp;&nbsp;&nbsp;</a></li>               
			   <li><a href="ViewMyCart.php">Shopping Cart</a></li>
               <li><a href="CheckOut.html">Check Out</a></li>
			   <li><a href="OrderHistory.html">Order History</a></li>				
          </ul>
       </nav>
				
		<form action="1tlogin.php" method="post">
         <?php include('errors.php')  ?>

			<a href="1tlogin.php" class="myButton" type="submit" name="login_user">Customer Login</a>
            </div>
	<div id="Loc">
			<br><em>Log in</em><br><br>
	</div>
		
	<div class="background">
		<p>Please Enter Your User Name&Password for log in</p>
		<div class="userin">
       <label for="bir" >Username</label>
      <input type="text" id="bir" value="" name="username" required>
			
     <label for="iki">Password</label>
     <input type="text" id="iki" value="" name="password" required><br>
	   <button type="submit" class="myButton1" type="submit" name="login_user" >Customer Login<br></button>
      <button type="submit" class="sumbit"  type="submit" name="adm_user">Client Login<br></button>
		<p>Not a user?<a href="1tregister.php">Clikc here to register~</a></p> 
			</div>
    </div>
    </form>

  <script src="http://www.jq22.com/jquery/1.11.1/jquery.min.js"></script>
  <script src="dist/login.js"></script>
		<div id="footer">
						<p class="footer-gd">Not Log in yet</p>
    </div>
		
</body>
</html>