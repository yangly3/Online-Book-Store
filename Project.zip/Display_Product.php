<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Home</title>
		<link href="demo.css" rel="stylesheet" type="text/css">
	</head>
	
	<body>
	   	<div class="header">
        <p><a href="#">ICS199 G15 Online Book Store</a></p>
        </div>
	
	    <div class="top_banner">
			
            <div class="top_logo"><img src="Images/1.gif" alt="LOGO" />
			</div>
         
        <nav class="dropdownmenu">
          	<ul>
               <li><a href="Product_View.php">Home</a></li>               
			   <li><a href="ViewMyCart.php">Shopping Cart</a></li>
               <li><a href="CheckOut.html">Check Out</a></li>
			   <li><a href="OrderHistory.html">Order History</a></li>				
          	</ul>
       	</nav>
		<a href="login.html" class="myButton">Log In</a>
		<form method="GET" action="Display_Product.php" class="styled-select green rounded" >
        	<select name="category"  >
				<option value="0">All</option>
		        <option value="1">Classic</option>
                <option value="2">Life</option>
                <option value="3">Science</option>
                <option value="4">Fiction</option>
                <option value="5">History</option>                    <     
			</select>
        <input type="submit" value="Search" id="Button1"  class="myButton1">
    	</form>			
			
 	</div>		

	<div id="Loc">
		<br><em>Welcome to ICS199 Online Book Store</em><br><br>
	</div>	
	
	<div id="table">

		<?php
			session_start();
			//include('includes/header.html');

			include('mysqli_connect.php');
			$category= $_GET['category'];
	
			if ($category=="0") {
				$query= "select * from Book;";
			}else{
				$query= "select * from Book where CategoryID =$category;";		
			}	
	
			$rows = mysqli_query($dbc,$query);
	
			echo '<table class="tftable" border="1">';
			echo '<tr><th>Book Name</th><th>Picture</th><th>Pirce</th><th>Description</th><th>AddToCart</th></tr>';
	
			while($row = mysqli_fetch_array($rows,MYSQLI_ASSOC)){
				$BookID =$row['BookID'];
				$BookName =$row['BookName'];
				$ISBNCode =$row['ISBNCode'];
				$Writer1 =$row['Writer1'];
				$Writer2 =$row['Writer2'];
				$Price =$row['Price'];
				$Description =$row['Description'];		
		
				echo "<tr><td>".$BookName.'</td><td><a href="#"><img src="Pics/'.$BookID.'.jpg" alt="book" height="150" width="120"/></a></td><td>$'.$Price.'</td><td>'.$Description.'</td><td><a href="#" class="add">AddToCart</a></td></tr>';
			}	
			echo '</table>';
			mysqli_close($dbc);		
		?>					
		</div>

	
	<div id="footer">
		<p class="footer-gd">Not Log in yet</p>
    	</div>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src="includes/script.js"></script>
</body>
</html>
