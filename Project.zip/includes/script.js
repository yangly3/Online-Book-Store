function addProduct(){
	alert("Product added.");
}
function removeProduct(){
	alert("Product removed.");
}
