<?php include('server.php')?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Register</title>
<link href="register.css" rel="stylesheet" type="text/css">
</head>

<body>
	   <div class="header">
        <p><a href="#">ICS199 G15 Online Book Store</a></p>
        </div>
	
	    <div class="top_banner">
			
            <div class="top_logo"><img src="Images/1.jpeg" alt="LOGO" />
			</div>
         
       <nav class="dropdownmenu">
          <ul>
               <li><a href="Product_View.php">&nbsp;&nbsp;&nbsp;Home&nbsp;&nbsp;&nbsp;</a></li>               
			   <li><a href="ViewMyCart.php">Shopping Cart</a></li>
               <li><a href="CheckOut.html">Check Out</a></li>
			   <li><a href="OrderHistory.html">Order History</a></li>				
          </ul>
       </nav>

<form action="1tregister.php" method="POST">
<?php include('errors.php')  ?>

			<a href="1tlogin.php" class="myButton" type="submit" name="login_user">Customer Login</a>
            </div>

	<div id="Loc">
			<br><em>Registration</em><br><br>
	</div>
		
	<div class="background">
		<p>Please enter your information below to create an Account:</p>
		<div class="userin">
        <label for="bir">Username</label>
        <input type="text" id="bir" value="" name="username" >
	    
		
        <label for="iki">Email</label>
        <input type="text" id="iki" value="" name="email" ><br>
		
		<label for="uc">Password</label>
        <input type="text" id="uc" value="" name="password" ><br>
			
		<label for="bl">Address</label>
        <input type="text" id="bl" value="" name="address" ><br>	

	     <button type="submit" class="sumbit"  type="submit" name="reg_user">Sumbit<br></button>
      
		 <p>Already a user?<a href="1tlogin.php">Click here to Log in~</a></p> 
			</div>

    </div>
    		</form>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="dist/login.js"></script>
	<div id="footer">
	    <p class="footer-gd">Not Log in yet</p>
    </div>
		
</body>
</html>
