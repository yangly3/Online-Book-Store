<!doctype html>
<html>
<head>
	<meta charset="utf-8">
	<title>View Cart</title>
	<link href="viewmycart.css" rel="stylesheet" type="text/css">
</head>
	
<body>
	<div class="header">
    	<p><a href="#">ICS199 G15 Online Book Store</a></p>
    </div>
	
	<div class="top_banner">
			
        <div class="top_logo"><img src="Images/1.jpeg" alt="LOGO"/>
		</div>
        <nav class="dropdownmenu">
          	<ul>
               <li><a href="Product_View.php">&nbsp;&nbsp;&nbsp;Home&nbsp;&nbsp;&nbsp;</a></li>               
			   <li><a href="ViewMyCart.php">Shopping Cart</a></li>
               <li><a href="CheckOut.html">Check Out</a></li>
			   <li><a href="OrderHistory.html">Order History</a></li>				
          	</ul>
       	</nav>
		<a href="login.html" class="myButton">Log Out</a>
    </div>
	
	<div id="Loc">
		<br><em>My Shopping Cart</em><br><br>
	</div>	
	
	<div id="table">
		<table class="tftable" border="1">
			<tr><th>Book name:</th><th>Image</th><th>Price</th><th>Quantity</th><th>Sub_total</th><th>Add one</th><th>Remove one</th><th>Delete All</th></tr>
			<form action="ViewMyCart.php" method="addProduct()"></form>
			<tr><td>Row:1 Cell:1</td><td><a href="#"><img src="Images/book_01.jpg" alt="book" width="120" height="150" /></a></td><td>Row:1 Cell:3</td><td>Row:1 Cell:4</td><td>Row:1 Cell:5</td>
			<td><a href="#" class="addButton" method="addProduct"> + </a></td><td><a href="#" class="remButton" onlclick="removeProduct()"> - </a></td><td><a href="#" class="delButton">Delete All</a></td></tr>
			<tr><td>Row:2 Cell:1</td><td><a href="#"><img src="Images/book_02.jpg" alt="book" height="150" width="120"/></a></td><td>Row:2 Cell:3</td><td>Row:2 Cell:4</td><td>Row:2 Cell:5</td><td><a href="#" class="addButton" onlclick="addProduct()"> + </a></td><td><a href="#" class="remButton" onlclick="removeProduct()"> - </a></td><td><a href="#" class="delButton">Delete All</a></td></tr>
		</table>
	</div>

	<div id="footer">
		<p class="footer-gd" style="color:red">Welcome! Log in information goes here</p>
    </div>

	<?php
	session_start();
	include('mysqli_connect.php');
		function addProduct(){
			
			$query = "select * from Book;";
			$rows = mysqli_query($dbc,$query);
			while($row = mysqli_fetch_array($rows,MYSQLI_ASSOC)){
				$BookName =$row['BookName'];
				$BookID =$row['BookID'];
				$Price =$row['Price'];
				$Quantity =$row['Quantity'] + 1;
				$Sub_total = $Price * $Quantity;
		
				echo "<tr><td>$BookName</td><td><a href=""><img src="Pics/$BookID.jpg" alt="book" height="150" width="120"/></a></td><td>$$Price</td><td>$Quantity</td><td>$Sub_total</td><td><a href="" class="addButton" method="addProduct"> + </a></td><td><a href="" class="remButton" onlclick="removeProduct()"> - </a></td><td><a href="" class="delButton">Delete All</a></td></tr>";
			}	
			echo '</table>';
			mysqli_close($dbc);
			
			//$addProduct = "INSERT INTO ShoppingCart (CustomerID, ShoppingDate) values (CustomerID, CURDATE());";
		}
	?>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src="includes/script.js"></script>
</body>
</html>
